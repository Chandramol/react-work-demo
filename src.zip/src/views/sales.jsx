import React from 'react'
import { Button } from "@/components/ui/button"

export default function sales() {
  return (
    <div>sales
        <Button>Click me</Button>

    </div>
  )
}
