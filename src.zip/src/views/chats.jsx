import React from 'react'

export default function chats() {
  return (
    <div>chats</div>
  )
}
